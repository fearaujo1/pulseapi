package com.pulseapi.entity.notificacao;

public enum TipoNotificacao {

    PRODUCAO_INICIADA,
    PRODUCAO_CONCLUIDA,

    EQUIPAMENTO_SEM_CONEXAO,
    EQUIPAMENTO_RECONECTADO,

    NOVA_OCORRENCIA,
    OCORRENCIA_CRITICA,

    ERRO_IMPRESSAO,
    IMPRESSAO_CONCLUIDA
}

