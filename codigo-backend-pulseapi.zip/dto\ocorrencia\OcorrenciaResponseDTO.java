package com.pulseapi.dto.ocorrencia;

import com.pulseapi.entity.ocorrencia.StatusOcorrencia;
import com.pulseapi.entity.ocorrencia.TipoOcorrencia;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class OcorrenciaResponseDTO {

    private Long id;
    private String titulo;
    private String descricao;
    private TipoOcorrencia tipo;
    private StatusOcorrencia status;
    private Long equipamentoId;
    private String equipamentoNome;
    private String equipamentoCodigo;
}